

package com.tunehub.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.PostMapping;
import com.tunehub.entities.PlayList;

import com.tunehub.entities.Songs;
import com.tunehub.services.PlaylistService;
import com.tunehub.services.SongService;


@Controller
public class PlaylistController {
	@Autowired
	SongService sserv;
	
	@Autowired
	PlaylistService pserv;
	@GetMapping("/createPlaylist")
	public String CreatePlaylist(Model model) {
		
		List<Songs> songslist= sserv.fetchAllSongs();
		model.addAttribute("songslist", songslist);
		
		return "createPlaylist";
	}
	
	@PostMapping("/addPlaylist")
	public String addPlayList(@ModelAttribute PlayList playlist) {
		//adding playlist
		pserv.addPlayList(playlist);
		
		//update song table
		
		//List<Songs> songslist= playlist.getSongs();
		List<Songs> songslist= sserv.fetchAllSongs();
		for(Songs songs : songslist) {
			songs.getPlaylist().add(playlist);
			sserv.updateSong(songs);
		}
		
		return "adminHome";
	}
	
	@GetMapping("/viewPlaylists")
	public String viewPlaylists(Model model) {
		
		List<PlayList> playlist= pserv.fetchPlaylists();
		model.addAttribute("playlist", playlist);
		
		return "displayPlaylists";
	}
	
	
}

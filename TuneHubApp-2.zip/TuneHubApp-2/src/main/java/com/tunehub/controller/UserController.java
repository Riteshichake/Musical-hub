package com.tunehub.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.tunehub.entities.Songs;
import com.tunehub.entities.User;
import com.tunehub.services.SongService;
import com.tunehub.services.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class UserController 
{
	@Autowired
	UserService userv;
	
	@Autowired
	SongService songserv;

	@PostMapping("/register")
	public String addUser(@ModelAttribute User user) {
		boolean userstatus = userv.emailExists(user.getEmail());
		if(userstatus == false) {
			userv.addUser(user);
			return "login";
		}
		else
		{
			return "login";
		}
	}

	@PostMapping("/validate")
	public String validateUser(@RequestParam String email,@RequestParam String password, HttpSession session)
	{
		//invoking validateUser() in service
		if(userv.validateUser(email, password) == true)
		{
			
			session.setAttribute("email", email);
			//checking whether the user is admin or customer
			if(userv.getRole(email).equals("admin"))
			{
				return "adminhome";
			}
			else
			{
				return "customerhome";
			}
		}
		else
		{
			return "login";
		}
	}
	
	@PostMapping("/forget")
	public String validUser(@RequestParam String email)
	{
		if(userv.validUser(email) == true)
		
		{
			
		return "reset";
		}
		else
		{
			return "login";
		}
		
	}
	@PostMapping("/Reset")
	public String Reset(@ModelAttribute User email,@ModelAttribute User password)
	{
		if(userv.Reset(email)==true)
{
		
		userv.addUser(password);
		return "resetsuccess";
}

		return "reset";
	}
		
	
	
	
	
	
	
	@GetMapping("/exploreSongs")
	public String exploreSongs(HttpSession session, Model model) {
		
String email =(String) session.getAttribute("email");

			
			User user = userv.getUser(email);
			user.isPremium();
			userv.updateUser(user);

			boolean userStatus = user.isPremium();
			if(userStatus == true) {
				java.util.List<Songs> songslist = songserv.fetchAllSongs();
				model.addAttribute("songslist", songslist);
				return "customerHome";
			}
			else {
				return "makepayment";
			}
	}
	
	
	
	
}
package com.tunehub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TuneHubApp2Application {

	public static void main(String[] args) {
		SpringApplication.run(TuneHubApp2Application.class, args);
	}

}

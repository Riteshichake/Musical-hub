package com.tunehub.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tunehub.entities.PlayList;
import com.tunehub.repositories.PlaylistRepository;

@Service
public class PlaylistServiceImplementation  implements PlaylistService
{
	@Autowired
	PlaylistRepository prepo;

	@Override
	public void addPlayList(PlayList playlist) {
		prepo.save(playlist);	
	}
	@Override
	public List<PlayList> fetchPlaylists() {
		return prepo.findAll();
	}
	
	
}
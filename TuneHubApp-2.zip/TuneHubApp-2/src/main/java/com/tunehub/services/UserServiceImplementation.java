package  com.tunehub.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tunehub.entities.User;
import com.tunehub.repositories.UserRepository;

@Service
public class UserServiceImplementation implements UserService
{
	@Autowired
	UserRepository repo;
	
	@Override
	public String addUser(User user) 
	{
		repo.save(user);
		return "user is created and saved";
	}

	@Override
	public boolean emailExists(String email) {
		
		if(repo.findByEmail(email) == null) 
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	@Override
	public boolean validateUser(String email, String password) {
		
		User user = repo.findByEmail(email);
		String db_password = user.getPassword();
		if(db_password.equals(password))
		{
			return true;
		}
		else
		{
			return false;
		}
		
		
	}

	@Override
	public String getRole(String email) {
		return (repo.findByEmail(email).getRole());
	}

	@Override
	public User getUser(String email) {
		return repo.findByEmail(email);
	}

	@Override
	public void updateUser(User user) {
		repo.save(user);
	}

	@Override
	public boolean validUser(String email) {
		// TODO Auto-generated method stub
		return true;
	}

	

	@Override
	public boolean Reset(User email) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean validUser(User email) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getId(User email) {
		// TODO Auto-generated method stub
		return repo.findAllById(email);
		
	}

	

	


	
}
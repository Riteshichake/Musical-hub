package com.tunehub.services;

import java.util.List;

import com.tunehub.entities.PlayList;

public interface PlaylistService 
{

	

	public List<PlayList> fetchPlaylists();

	public void addPlayList(PlayList playlist);

	

}
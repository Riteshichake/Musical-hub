package com.tunehub.repositories;

import org.springframework.data.jpa.repository.JpaRepository;


import com.tunehub.entities.User;

public interface UserRepository extends JpaRepository<User, Integer>  {
	
	public User findByEmail(String email);

	public void save(String email);

	public int findAllById(User email);
}